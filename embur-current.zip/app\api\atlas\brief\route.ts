import { NextResponse } from "next/server";
import { auth } from "@clerk/nextjs/server";
import { getOpenAIClient } from "@/lib/openai";
import type { AtlasMemory } from "@/lib/intelligence/memory/types";
import type { AtlasSnapshot } from "@/lib/intelligence/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type AtlasBriefRequest = {
  snapshot?: AtlasSnapshot;
  memory?: AtlasMemory | null;
};

export async function POST(request: Request) {
  try {
    const {
      isAuthenticated,
      orgId,
    } = await auth();

    if (!isAuthenticated) {
      return NextResponse.json(
        {
          success: false,
          message: "You must sign in.",
        },
        {
          status: 401,
        }
      );
    }

    if (!orgId) {
      return NextResponse.json(
        {
          success: false,
          message:
            "Select a company before loading an Atlas brief.",
        },
        {
          status: 409,
        }
      );
    }

    const body =
      (await request.json()) as AtlasBriefRequest;

    if (!body.snapshot) {
      return NextResponse.json(
        {
          success: false,
          message:
            "The current Atlas business snapshot is missing.",
        },
        {
          status: 400,
        }
      );
    }

    if (!process.env.OPENAI_API_KEY) {
      return NextResponse.json(
        {
          success: false,
          message:
            "OPENAI_API_KEY is not configured.",
        },
        {
          status: 500,
        }
      );
    }

    const model =
      process.env.OPENAI_MODEL?.trim();

    if (!model) {
      return NextResponse.json(
        {
          success: false,
          message:
            "OPENAI_MODEL is not configured.",
        },
        {
          status: 500,
        }
      );
    }

    const snapshot = body.snapshot;
    const memory = body.memory;

    const ownerName =
      memory?.ownerName?.trim() || "Owner";

    const client = getOpenAIClient();

    const response =
      await client.responses.create({
        model,

        instructions: [
          "You are Atlas, the executive operating intelligence inside EMBUR.",
          "Write a concise daily briefing for a local service business owner.",
          "Use only the supplied business data and owner preferences.",
          "Never invent customers, revenue, appointments, dates, completed actions, or outcomes.",
          "Sound calm, confident, direct, and practical.",
          "Do not sound like a chatbot.",
          "Give one clear first action.",
          "Do not claim that EMBUR completed an action.",
          "Do not use markdown headings, bullet points, or emojis.",
          "Keep the briefing between 80 and 140 words.",
        ].join(" "),

        input: JSON.stringify({
          ownerName,

          preferences: {
            briefLength:
              memory?.preferredBriefLength ??
              "short",

            communication:
              memory?.preferredCommunication ??
              "call",

            emergencyFirst:
              memory?.emergencyFirst ??
              true,

            preferredStartHour:
              memory?.preferredStartHour ??
              8,

            expectedResponseMinutes:
              memory?.averageResponseMinutes ??
              15,
          },

          business: {
            health:
              snapshot.businessHealth,

            healthSummary:
              snapshot.businessHealthSummary,

            revenueAtRisk:
              snapshot.revenueAtRisk,

            pipeline:
              snapshot.forecast.pipeline,

            expectedRevenue:
              snapshot.forecast.expectedRevenue,

            expectedAppointments:
              snapshot.forecast
                .expectedAppointments,

            waitingCustomers:
              snapshot.metrics.waitingCustomers,

            bookedCustomers:
              snapshot.metrics.bookedCustomers,

            followUpCustomers:
              snapshot.metrics.followUpCustomers,

            totalCustomers:
              snapshot.metrics.totalCustomers,
          },

          topPriority: {
            customerName:
              snapshot.topPriority.customer.name,

            service:
              snapshot.topPriority.customer.service,

            status:
              snapshot.topPriority.customer.status,

            estimatedValue:
              snapshot.topPriority.estimatedValue,

            score:
              snapshot.topPriority.score,

            confidence:
              snapshot.topPriority.confidence,

            riskLevel:
              snapshot.topPriority.riskLevel,

            reason:
              snapshot.topPriority.reason,

            recommendedAction:
              snapshot.topPriority
                .recommendedAction,
          },

          recommendations:
            snapshot.recommendations.map(
              (recommendation) => ({
                title:
                  recommendation.title,

                description:
                  recommendation.description,

                actionType:
                  recommendation.actionType,

                riskLevel:
                  recommendation.riskLevel,

                estimatedValue:
                  recommendation.estimatedValue,
              })
            ),
        }),
      });

    const brief =
      response.output_text?.trim();

    if (!brief) {
      throw new Error(
        "Atlas returned an empty briefing."
      );
    }

    return NextResponse.json({
      success: true,
      brief,
      source: "openai",
    });
  } catch (error) {
    console.error(
      "Atlas brief route failed:",
      error
    );

    return NextResponse.json(
      {
        success: false,
        message:
          error instanceof Error
            ? error.message
            : "Atlas AI is temporarily unavailable.",
      },
      {
        status: 500,
      }
    );
  }
}